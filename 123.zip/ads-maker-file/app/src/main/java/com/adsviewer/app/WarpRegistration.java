package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class WarpRegistration {
    private static final String TAG = "AdsViewer/WARP-REG";

    private static final String REG_URL = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String UA = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";

    private static final String K_PRIV = "warp_priv";
    private static final String K_PUB = "warp_pub";
    private static final String K_SRV_PUB = "warp_srv_pub";
    private static final String K_ENDPOINT = "warp_endpoint";
    private static final String K_V4 = "warp_v4";
    private static final String K_V6 = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";

    // ---------------- COUNTRY ENUM ----------------
    public enum Country {
        US("US"),
        UK("GB"),
        AU("AU"),
        SG("SG");

        public final String code;
        Country(String code) { this.code = code; }
    }

    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
    }

    public static class CountryResult {
        public final Country requested;
        public final String actual;
        public final boolean matched;

        public CountryResult(Country requested, String actual, boolean matched) {
            this.requested = requested;
            this.actual = actual;
            this.matched = matched;
        }
    }

    // ---------------- MAIN LOGIC ----------------
    public static WarpConfig getOrRegister(SharedPreferences prefs, boolean forceFreshRegistration)
            throws Exception {

        if (!forceFreshRegistration && prefs.contains(K_PRIV) && prefs.contains(K_SRV_PUB)) {
            WarpConfig c = new WarpConfig();
            c.privateKeyBase64 = prefs.getString(K_PRIV, null);
            c.publicKeyBase64 = prefs.getString(K_PUB, null);
            c.serverPublicKey = prefs.getString(K_SRV_PUB, null);
            c.endpoint = prefs.getString(K_ENDPOINT, null);
            c.v4Address = prefs.getString(K_V4, null);
            c.v6Address = prefs.getString(K_V6, null);
            c.clientId = prefs.getString(K_CLIENT_ID, null);

            Log.d(TAG, "Reusing cached WARP: " + c.v4Address);
            return c;
        }

        KeyPair kp = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64 = kp.getPublicKey().toBase64();

        JSONObject body = new JSONObject();
        body.put("key", pubB64);
        body.put("install_id", "");
        body.put("fcm_token", "");
        body.put("tos", iso8601Now());
        body.put("model", "PC");
        body.put("type", "Android");
        body.put("locale", "en_US");

        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request req = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent", UA)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String respText;
        try (Response resp = http.newCall(req).execute()) {
            ResponseBody rb = resp.body();
            respText = rb != null ? rb.string() : "";

            if (!resp.isSuccessful()) {
                throw new IOException("HTTP " + resp.code() + ": " + respText);
            }
        }

        JSONObject json = new JSONObject(respText);
        JSONObject config = json.getJSONObject("config");

        JSONArray peers = config.getJSONArray("peers");
        JSONObject peer0 = peers.getJSONObject(0);

        String srvPub = peer0.getString("public_key");
        String endpoint = peer0.getJSONObject("endpoint").getString("host");

        JSONObject iface = config.getJSONObject("interface");
        JSONObject addrs = iface.getJSONObject("addresses");

        String v4 = addrs.getString("v4");
        String v6 = addrs.getString("v6");

        String clientId = config.optString("client_id", "");

        // SAFE KEY VALIDATION
        try {
            Key.fromBase64(privB64);
            Key.fromBase64(srvPub);
        } catch (Exception e) {
            throw new IOException("Invalid key format", e);
        }

        WarpConfig c = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64 = pubB64;
        c.serverPublicKey = srvPub;
        c.endpoint = endpoint;
        c.v4Address = v4;
        c.v6Address = v6;
        c.clientId = clientId;

        prefs.edit()
                .putString(K_PRIV, c.privateKeyBase64)
                .putString(K_PUB, c.publicKeyBase64)
                .putString(K_SRV_PUB, c.serverPublicKey)
                .putString(K_ENDPOINT, c.endpoint)
                .putString(K_V4, c.v4Address)
                .putString(K_V6, c.v6Address)
                .putString(K_CLIENT_ID, c.clientId)
                .apply();

        Log.d(TAG, "WARP Registered: " + c.v4Address);
        return c;
    }

    // ---------------- COUNTRY DETECTION ----------------
    public static String detectCountry() throws IOException {
        OkHttpClient http = new OkHttpClient();

        Request req = new Request.Builder()
                .url("https://ipinfo.io/json")
                .build();

        try (Response resp = http.newCall(req).execute()) {
            if (!resp.isSuccessful()) {
                throw new IOException("IP check failed");
            }

            String text = resp.body().string();
            JSONObject json = new JSONObject(text);
            return json.optString("country", "UNKNOWN");
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    // ---------------- SELECTOR LOGIC ----------------
    public static CountryResult selectRegion(SharedPreferences prefs, Country preferred)
            throws Exception {

        clearCache(prefs);

        WarpConfig cfg = getOrRegister(prefs, true);

        String actual = detectCountry();

        boolean matched = actual.equalsIgnoreCase(preferred.code);

        Log.d(TAG, "Preferred=" + preferred.code + " Got=" + actual);

        return new CountryResult(preferred, actual, matched);
    }

    // ---------------- UTIL ----------------
    public static void clearCache(SharedPreferences prefs) {
        prefs.edit().clear().apply();
    }

    private static String iso8601Now() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }
}