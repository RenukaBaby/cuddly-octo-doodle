package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.Dns;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Handles Cloudflare WARP device registration AND traffic routing.
 *
 * CRITICAL UNDERSTANDING:
 * ─────────────────────────────────────────────────────────────────
 * Registration alone does NOT change your IP address.
 * You must route ALL traffic through the WireGuard tunnel.
 *
 * There are two approaches depending on your use case:
 *
 * APPROACH 1 — VpnService (system-wide, changes IP for ALL apps):
 *   Use Android's VpnService API to create a TUN interface.
 *   All device traffic is routed through WireGuard tunnel.
 *   → See WarpTunnelService.java
 *
 * APPROACH 2 — Per-request proxying via SOCKS5 (changes IP only for OkHttp calls):
 *   Route specific OkHttp requests through a local WireGuard-backed SOCKS5 proxy.
 *   → Use getProxiedHttpClient()
 *
 * APPROACH 3 — Use Cloudflare's WARP+ SOCKS5 proxy directly (easiest):
 *   WARP exposes a local SOCKS5 proxy at 127.0.0.1:40000 when the WARP
 *   app/daemon is running. If you control the environment, just proxy through that.
 *
 * WHY YOUR IP WAS NOT CHANGING:
 * ─────────────────────────────────────────────────────────────────
 * You were only registering a WireGuard identity with Cloudflare.
 * That is equivalent to creating a VPN account but never connecting.
 * The actual WireGuard tunnel (kernel/userspace TUN device) was never
 * established, so all traffic continued using the default network interface.
 */
public final class WarpRegistration {

    private static final String TAG = "AdsViewer/WARP-REG";

    // ── Cloudflare WARP API ───────────────────────────────────────────────────
    private static final String REG_URL          = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String USER_AGENT        = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";

    // ── HTTP timeouts ─────────────────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SECONDS = 15;
    private static final int READ_TIMEOUT_SECONDS    = 20;

    // ── WARP SOCKS5 proxy (exposed by WARP daemon when running) ──────────────
    // When using VpnService approach, set up your own local SOCKS5 proxy port.
    private static final String WARP_SOCKS5_HOST = "127.0.0.1";
    private static final int    WARP_SOCKS5_PORT = 40000;

    // ── SharedPreferences keys ────────────────────────────────────────────────
    private static final String K_PRIV      = "warp_priv";
    private static final String K_PUB       = "warp_pub";
    private static final String K_SRV_PUB   = "warp_srv_pub";
    private static final String K_ENDPOINT  = "warp_endpoint";
    private static final String K_V4        = "warp_v4";
    private static final String K_V6        = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";

    // ── JSON field names ──────────────────────────────────────────────────────
    private static final String J_CONFIG     = "config";
    private static final String J_PEERS      = "peers";
    private static final String J_PUB_KEY    = "public_key";
    private static final String J_ENDPOINT   = "endpoint";
    private static final String J_HOST       = "host";
    private static final String J_INTERFACE  = "interface";
    private static final String J_ADDRESSES  = "addresses";
    private static final String J_V4         = "v4";
    private static final String J_V6         = "v6";
    private static final String J_CLIENT_ID  = "client_id";
    private static final String J_KEY        = "key";
    private static final String J_INSTALL_ID = "install_id";
    private static final String J_FCM_TOKEN  = "fcm_token";
    private static final String J_TOS        = "tos";
    private static final String J_MODEL      = "model";
    private static final String J_TYPE       = "type";
    private static final String J_LOCALE     = "locale";

    // ── Shared HTTP client (no proxy — for registration calls only) ───────────
    @Nullable private static volatile OkHttpClient sRegistrationClient;

    // ── Shared HTTP client (proxied through WARP tunnel) ─────────────────────
    @Nullable private static volatile OkHttpClient sProxiedClient;

    private WarpRegistration() {
        throw new UnsupportedOperationException("Static utility class.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public data model
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Immutable, fully resolved WARP / WireGuard configuration.
     *
     * This alone does NOT change your IP. You must pass this config to either:
     *   1. {@link WarpTunnelService} to establish a VPN tunnel (system-wide IP change)
     *   2. {@link #buildWireGuardConfig(WarpConfig)} to get a wg-quick style config string
     *      that you feed into a WireGuard tunnel manager
     */
    public static final class WarpConfig {
        public final String privateKeyBase64;
        public final String publicKeyBase64;
        public final String serverPublicKey;
        public final String endpoint;
        public final String v4Address;
        public final String v6Address;
        public final String clientId;

        private WarpConfig(
                @NonNull String privateKeyBase64,
                @NonNull String publicKeyBase64,
                @NonNull String serverPublicKey,
                @NonNull String endpoint,
                @NonNull String v4Address,
                @NonNull String v6Address,
                @NonNull String clientId) {
            this.privateKeyBase64 = privateKeyBase64;
            this.publicKeyBase64  = publicKeyBase64;
            this.serverPublicKey  = serverPublicKey;
            this.endpoint         = endpoint;
            this.v4Address        = v4Address;
            this.v6Address        = v6Address;
            this.clientId         = clientId;
        }

        @NonNull
        @Override
        public String toString() {
            // Never log privateKeyBase64
            return "WarpConfig{endpoint='" + endpoint
                    + "', v4='" + v4Address
                    + "', v6='" + v6Address
                    + "', srvPub='" + serverPublicKey + "'}";
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Registration
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns cached config or registers a new WARP device.
     *
     * IMPORTANT: After calling this, you MUST establish the WireGuard tunnel.
     * Call {@link #buildWireGuardConfig(WarpConfig)} and pass the result to
     * your VpnService or WireGuard tunnel implementation.
     */
    @NonNull
    public static WarpConfig getOrRegister(
            @NonNull SharedPreferences prefs,
            boolean forceFreshRegistration) throws Exception {

        if (!forceFreshRegistration) {
            WarpConfig cached = tryLoadFromPrefs(prefs);
            if (cached != null) {
                Log.d(TAG, "Reusing cached WARP registration: " + cached);
                return cached;
            }
        }

        return registerNewDevice(prefs);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // THE MISSING PIECE — WireGuard config generation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Converts a {@link WarpConfig} into a wg-quick compatible config string.
     *
     * THIS IS WHAT YOU WERE MISSING. You must feed this string into either:
     *   - Android's WireGuard tunnel library (com.wireguard.android:tunnel)
     *   - A VpnService implementation that reads this config
     *   - The wireguard-android GoBackend
     *
     * The config routes ALL traffic (0.0.0.0/0, ::/0) through WARP,
     * which causes every outbound connection to appear to come from
     * Cloudflare's IP space — changing your visible public IP.
     *
     * @param config A registered WarpConfig from {@link #getOrRegister}.
     * @return wg-quick config string ready for tunnel activation.
     */
    @NonNull
    public static String buildWireGuardConfig(@NonNull WarpConfig config) {
        // Decode clientId (base64) → 3 reserved bytes → hex for Table field
        // Some WireGuard implementations accept reserved as a hex string in DNS field
        // For wireguard-android GoBackend, pass via IPC as shown below.

        return "[Interface]\n"
                + "PrivateKey = "   + config.privateKeyBase64             + "\n"
                + "Address = "      + config.v4Address + "/32, "
                                   + config.v6Address + "/128"            + "\n"
                + "DNS = 1.1.1.1, 1.0.0.1, 2606:4700:4700::1111\n"
                + "MTU = 1280\n"
                + "\n"
                + "[Peer]\n"
                + "PublicKey = "    + config.serverPublicKey               + "\n"
                // AllowedIPs = 0.0.0.0/0 means ALL traffic goes through WARP
                // This is what actually changes your IP address
                + "AllowedIPs = 0.0.0.0/0, ::/0\n"
                + "Endpoint = "     + resolveEndpoint(config.endpoint)    + "\n"
                + "PersistentKeepalive = 25\n";
    }

    /**
     * Builds a WireGuard IPC configuration string for use with the
     * wireguard-android GoBackend (com.wireguard.android:tunnel).
     *
     * Use this with:
     *   GoBackend backend = new GoBackend(context);
     *   backend.setState(tunnel, UP, parseIpcConfig(config));
     *
     * @param config A registered WarpConfig.
     * @return IPC config string for GoBackend.
     */
    @NonNull
    public static String buildGoBackendIpcConfig(@NonNull WarpConfig config) {
        String[] endpointParts = splitEndpoint(config.endpoint);
        String   host          = endpointParts[0];
        String   port          = endpointParts[1];

public static String yourMethodName(...) {

    try {
        String privateKey = toHex(Key.fromBase64(config.privateKeyBase64).getBytes());
        String publicKey  = toHex(Key.fromBase64(config.serverPublicKey).getBytes());

        return "private_key=" + privateKey + "\n"
             + "public_key=" + publicKey + "\n";

    } catch (Exception e) {
        throw new RuntimeException("Key parsing failed", e);
    }
}

    // ─────────────────────────────────────────────────────────────────────────
    // Proxied HTTP client — routes requests through the WARP SOCKS5 proxy
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns an {@link OkHttpClient} whose traffic is routed through the
     * WARP SOCKS5 proxy at {@code 127.0.0.1:40000}.
     *
     * PREREQUISITE: The WARP tunnel must already be active (VpnService running).
     * When active, WARP exposes a local SOCKS5 proxy that forwards traffic
     * through the WireGuard tunnel, causing requests to appear from Cloudflare IPs.
     *
     * Usage:
     *   OkHttpClient client = WarpRegistration.getProxiedHttpClient();
     *   Request req = new Request.Builder().url("https://api.ipify.org").build();
     *   // This request will show a Cloudflare IP, not your real IP.
     *   Response resp = client.newCall(req).execute();
     *
     * @param socksHost Host of local SOCKS5 proxy (usually "127.0.0.1")
     * @param socksPort Port of local SOCKS5 proxy (usually 40000 for WARP)
     */
    @NonNull
    public static OkHttpClient getProxiedHttpClient(
            @NonNull String socksHost,
            int socksPort) {

        if (sProxiedClient == null) {
            synchronized (WarpRegistration.class) {
                if (sProxiedClient == null) {
                    Proxy socks5Proxy = new Proxy(
                            Proxy.Type.SOCKS,
                            new InetSocketAddress(socksHost, socksPort));

                    sProxiedClient = new OkHttpClient.Builder()
                            .proxy(socks5Proxy)
                            // Force DNS resolution through the proxy tunnel,
                            // not the local resolver — prevents DNS leaks.
                            .dns(hostname -> {
                                // Return unresolved so SOCKS5 proxy resolves DNS
                                // This prevents DNS leaks through your real IP
                                return Arrays.asList(
                                        InetAddress.getByAddress(hostname, new byte[]{0,0,0,0}));
                            })
                            .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                            .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                            .build();
                }
            }
        }
        return sProxiedClient;
    }

    /**
     * Convenience overload using default WARP SOCKS5 proxy address.
     */
    @NonNull
    public static OkHttpClient getProxiedHttpClient() {
        return getProxiedHttpClient(WARP_SOCKS5_HOST, WARP_SOCKS5_PORT);
    }

    /**
     * Verifies that traffic is actually routed through WARP by checking
     * what IP address the outside world sees.
     *
     * A Cloudflare IP (e.g. 104.x.x.x or 162.x.x.x) confirms the tunnel works.
     *
     * @return The public IP seen by external servers, or null on failure.
     */
    @Nullable
    public static String verifyTunnelIp() {
        try {
            OkHttpClient client = getProxiedHttpClient();
            Request req = new Request.Builder()
                    .url("https://api.ipify.org?format=json")
                    .header("User-Agent", USER_AGENT)
                    .get()
                    .build();

            try (Response resp = client.newCall(req).execute()) {
                if (resp.isSuccessful() && resp.body() != null) {
                    String body = resp.body().string();
                    Log.d(TAG, "Tunnel verification — public IP seen: " + body);
                    return new JSONObject(body).optString("ip");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Tunnel IP verification failed: " + e.getMessage());
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Cache management
    // ─────────────────────────────────────────────────────────────────────────

    public static void clearCache(@NonNull SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_ENDPOINT).remove(K_V4).remove(K_V6).remove(K_CLIENT_ID)
                .apply();
        Log.d(TAG, "WARP registration cache cleared.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    @NonNull
    private static WarpConfig registerNewDevice(@NonNull SharedPreferences prefs)
            throws Exception {
        Log.d(TAG, "Registering new WARP device with Cloudflare...");

        KeyPair kp     = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64  = kp.getPublicKey().toBase64();

        String     responseBody = executeRegistrationRequest(pubB64);
        WarpConfig config       = parseRegistrationResponse(responseBody, privB64, pubB64);

        persistConfig(prefs, config);

        Log.d(TAG, "New WARP device registered: " + config);
        Log.d(TAG, "─────────────────────────────────────────────────");
        Log.d(TAG, "NEXT STEP: Call buildWireGuardConfig() and activate");
        Log.d(TAG, "the tunnel via VpnService or GoBackend.");
        Log.d(TAG, "Registration alone does NOT change your IP address.");
        Log.d(TAG, "─────────────────────────────────────────────────");

        return config;
    }

    @NonNull
    private static String executeRegistrationRequest(@NonNull String publicKeyBase64)
            throws IOException, JSONException {

        String bodyJson = buildRegistrationBody(publicKeyBase64);

        Request request = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent",        USER_AGENT)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type",      "application/json")
                .post(RequestBody.create(
                        bodyJson,
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        try (Response response = registrationHttpClient().newCall(request).execute()) {
            ResponseBody rb       = response.body();
            String       respText = rb != null ? rb.string() : "";

            if (!response.isSuccessful()) {
                throw new IOException(
                        "WARP registration failed — HTTP "
                                + response.code() + ": " + respText);
            }
            Log.d(TAG, "WARP reg response (" + respText.length() + " chars)");
            return respText;
        }
    }

    @NonNull
    private static String buildRegistrationBody(@NonNull String publicKeyBase64)
            throws JSONException {
        return new JSONObject()
                .put(J_KEY,        publicKeyBase64)
                .put(J_INSTALL_ID, "")
                .put(J_FCM_TOKEN,  "")
                .put(J_TOS,        iso8601Now())
                .put(J_MODEL,      "PC")
                .put(J_TYPE,       "Android")
                .put(J_LOCALE,     "en_US")
                .toString();
    }

    @NonNull
    private static WarpConfig parseRegistrationResponse(
            @NonNull String json,
            @NonNull String privB64,
            @NonNull String pubB64) throws Exception {

        JSONObject root   = new JSONObject(json);
        JSONObject config = root.getJSONObject(J_CONFIG);

        JSONObject peer0  = config.getJSONArray(J_PEERS).getJSONObject(0);
        String     srvPub = peer0.getString(J_PUB_KEY);
        String     epHost = peer0.getJSONObject(J_ENDPOINT).getString(J_HOST);

        JSONObject addresses = config.getJSONObject(J_INTERFACE).getJSONObject(J_ADDRESSES);
        String v4       = addresses.getString(J_V4);
        String v6       = addresses.getString(J_V6);
        String clientId = config.optString(J_CLIENT_ID, "");

        // Validate keys before persisting
        Key.fromBase64(privB64);
        Key.fromBase64(srvPub);

        return new WarpConfig(privB64, pubB64, srvPub, epHost, v4, v6, clientId);
    }

    @Nullable
    private static WarpConfig tryLoadFromPrefs(@NonNull SharedPreferences prefs) {
        String priv     = prefs.getString(K_PRIV,      null);
        String pub      = prefs.getString(K_PUB,       null);
        String srvPub   = prefs.getString(K_SRV_PUB,   null);
        String endpoint = prefs.getString(K_ENDPOINT,  null);
        String v4       = prefs.getString(K_V4,        null);
        String v6       = prefs.getString(K_V6,        null);
        String clientId = prefs.getString(K_CLIENT_ID, "");

        if (priv == null || pub == null || srvPub == null
                || endpoint == null || v4 == null || v6 == null) {
            return null;
        }
        return new WarpConfig(priv, pub, srvPub, endpoint, v4, v6, clientId);
    }

    private static void persistConfig(
            @NonNull SharedPreferences prefs,
            @NonNull WarpConfig config) {
        prefs.edit()
                .putString(K_PRIV,      config.privateKeyBase64)
                .putString(K_PUB,       config.publicKeyBase64)
                .putString(K_SRV_PUB,   config.serverPublicKey)
                .putString(K_ENDPOINT,  config.endpoint)
                .putString(K_V4,        config.v4Address)
                .putString(K_V6,        config.v6Address)
                .putString(K_CLIENT_ID, config.clientId)
                .apply();
    }

    /** Resolves "host:port" endpoint, returning "ip:port" to avoid DNS at tunnel time. */
    @NonNull
    private static String resolveEndpoint(@NonNull String hostPort) {
        try {
            String[] parts = splitEndpoint(hostPort);
            InetAddress addr = InetAddress.getByName(parts[0]);
            return addr.getHostAddress() + ":" + parts[1];
        } catch (Exception e) {
            Log.w(TAG, "Could not pre-resolve endpoint, using as-is: " + hostPort);
            return hostPort;
        }
    }

    @NonNull
    private static String[] splitEndpoint(@NonNull String hostPort) {
        int lastColon = hostPort.lastIndexOf(':');
        if (lastColon < 0) return new String[]{hostPort, "2408"};
        return new String[]{
                hostPort.substring(0, lastColon),
                hostPort.substring(lastColon + 1)
        };
    }

    @NonNull
    private static String toHex(@NonNull byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    @NonNull
    private static String iso8601Now() {
        SimpleDateFormat df =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }

    @NonNull
    private static OkHttpClient registrationHttpClient() {
        if (sRegistrationClient == null) {
            synchronized (WarpRegistration.class) {
                if (sRegistrationClient == null) {
                    sRegistrationClient = new OkHttpClient.Builder()
                            .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                            .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                            .build();
                }
            }
        }
        return sRegistrationClient;
    }
}