package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Handles Cloudflare WARP device registration.
 *
 * <p>Hits our own self-hosted registration proxy (Node.js / Express) which mirrors
 * the real Cloudflare WARP consumer API shape:
 * {@code POST <SERVER_BASE_URL>/<API_VERSION>/reg}
 *
 * <p>Each call returns a fresh WARP-style identity (WireGuard server pubkey, endpoint,
 * client v4/v6 addresses, and a base64 client_id used as WireGuard "reserved" bytes).
 *
 * <p>The resulting config is persisted in {@link SharedPreferences} so the app reuses
 * the same device unless explicit rotation is requested via {@code forceFreshRegistration}.
 */
public final class WarpRegistration {

    private static final String TAG = "AdsViewer/WARP-REG";

    // ── Server configuration ──────────────────────────────────────────────────
    /**
     * Base URL of your self-hosted registration proxy.
     * Change this to your server's address before building.
     * Example: "https://your-server.com" or "http://10.0.2.2:3000" for emulator localhost.
     */
    private static final String SERVER_BASE_URL = "http://10.0.2.2:3000";

    // ── API constants ─────────────────────────────────────────────────────────
    /**
     * API version segment — must match one of the versions declared in
     * {@code SUPPORTED_API_VERSIONS} on the server side.
     */
    private static final String API_VERSION      = "v0a2405";
    private static final String REG_URL          = SERVER_BASE_URL + "/" + API_VERSION + "/reg";
    private static final String USER_AGENT        = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";
    private static final MediaType JSON_MEDIA_TYPE =
            MediaType.parse("application/json; charset=utf-8");

    // ── HTTP timeouts ─────────────────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SECONDS = 15;
    private static final int READ_TIMEOUT_SECONDS    = 20;

    // ── SharedPreferences keys ────────────────────────────────────────────────
    private static final String K_PRIV      = "warp_priv";
    private static final String K_PUB       = "warp_pub";
    private static final String K_SRV_PUB   = "warp_srv_pub";
    private static final String K_ENDPOINT  = "warp_endpoint";
    private static final String K_V4        = "warp_v4";
    private static final String K_V6        = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";

    // ── Shared HTTP client (reuse across calls) ───────────────────────────────
    private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build();

    // Prevent instantiation — static utility class
    private WarpRegistration() {}

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Immutable value object holding all fields required to build a WireGuard tunnel.
     */
    public static final class WarpConfig {
        /** Our WireGuard private key (base64). */
        public final String privateKeyBase64;
        /** Our WireGuard public key (base64). */
        public final String publicKeyBase64;
        /** Server's WireGuard public key (base64). */
        public final String serverPublicKey;
        /** Tunnel endpoint in {@code host:port} format. */
        public final String endpoint;
        /** Assigned IPv4 address (e.g. {@code 172.16.0.x}). */
        public final String v4Address;
        /** Assigned IPv6 address (e.g. {@code 2606:...}). */
        public final String v6Address;
        /** Base64 client_id used as WireGuard {@code reserved} bytes. */
        public final String clientId;

        private WarpConfig(
                String privateKeyBase64,
                String publicKeyBase64,
                String serverPublicKey,
                String endpoint,
                String v4Address,
                String v6Address,
                String clientId) {
            this.privateKeyBase64 = privateKeyBase64;
            this.publicKeyBase64  = publicKeyBase64;
            this.serverPublicKey  = serverPublicKey;
            this.endpoint         = endpoint;
            this.v4Address        = v4Address;
            this.v6Address        = v6Address;
            this.clientId         = clientId;
        }

        @Override
        public String toString() {
            return "WarpConfig{v4=" + v4Address + ", v6=" + v6Address
                    + ", endpoint=" + endpoint + "}";
        }
    }

    /**
     * Returns a cached {@link WarpConfig} when available, or registers a new WARP device
     * via the self-hosted proxy and caches the result.
     *
     * @param prefs                  {@link SharedPreferences} used for persistence.
     * @param forceFreshRegistration When {@code true}, ignores any cached state and
     *                               performs a fresh registration (identity rotation).
     * @return A fully populated {@link WarpConfig}.
     * @throws Exception on network failure, unexpected HTTP status, or JSON parse errors.
     */
    public static WarpConfig getOrRegister(
            SharedPreferences prefs,
            boolean forceFreshRegistration) throws Exception {

        if (!forceFreshRegistration && isCached(prefs)) {
            return loadFromCache(prefs);
        }

        return registerNewDevice(prefs);
    }

    /**
     * Removes all cached WARP registration data from {@link SharedPreferences}.
     *
     * @param prefs {@link SharedPreferences} to clear.
     */
    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV)
                .remove(K_PUB)
                .remove(K_SRV_PUB)
                .remove(K_ENDPOINT)
                .remove(K_V4)
                .remove(K_V6)
                .remove(K_CLIENT_ID)
                .apply();

        Log.d(TAG, "WARP cache cleared.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /** Returns {@code true} if all required keys are present in prefs. */
    private static boolean isCached(SharedPreferences prefs) {
        return prefs.contains(K_PRIV) && prefs.contains(K_SRV_PUB);
    }

    /** Rebuilds a {@link WarpConfig} from persisted prefs — no network call. */
    private static WarpConfig loadFromCache(SharedPreferences prefs) {
        WarpConfig config = new WarpConfig(
                prefs.getString(K_PRIV,      null),
                prefs.getString(K_PUB,       null),
                prefs.getString(K_SRV_PUB,   null),
                prefs.getString(K_ENDPOINT,  null),
                prefs.getString(K_V4,        null),
                prefs.getString(K_V6,        null),
                prefs.getString(K_CLIENT_ID, null)
        );
        Log.d(TAG, "Reusing cached WARP registration: " + config);
        return config;
    }

    /** Generates a new keypair, calls the proxy API, persists and returns the result. */
    private static WarpConfig registerNewDevice(SharedPreferences prefs) throws Exception {
        Log.d(TAG, "Registering new WARP device via proxy: " + REG_URL);

        // Generate a fresh WireGuard keypair locally
        KeyPair keyPair = new KeyPair();
        String  privB64 = keyPair.getPrivateKey().toBase64();
        String  pubB64  = keyPair.getPublicKey().toBase64();

        String     rawJson = performRegistrationRequest(pubB64);
        WarpConfig config  = parseRegistrationResponse(rawJson, privB64, pubB64);

        // Eagerly validate that both keys are parseable before we persist anything
        Key.fromBase64(config.privateKeyBase64);
        Key.fromBase64(config.serverPublicKey);

        persistToCache(prefs, config);

        Log.d(TAG, "WARP device registered: " + config);
        return config;
    }

    /**
     * Sends the registration POST request to the self-hosted proxy and returns the raw
     * response body.
     *
     * <p>Headers ({@code User-Agent}, {@code CF-Client-Version}) must satisfy the
     * server-side validation middleware or the request will be rejected with HTTP 403.
     *
     * @param publicKeyBase64 The client's WireGuard public key (base64).
     * @return Raw JSON response string.
     * @throws IOException on network failure or non-2xx HTTP status.
     * @throws Exception   on JSON construction failure.
     */
    private static String performRegistrationRequest(String publicKeyBase64) throws Exception {
        JSONObject body = new JSONObject()
                .put("key",        publicKeyBase64)
                .put("install_id", "")
                .put("fcm_token",  "")
                .put("tos",        iso8601Now())
                .put("model",      "PC")
                .put("type",       "Android")
                .put("locale",     "en_US");

        Request request = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent",        USER_AGENT)        // validated server-side
                .header("CF-Client-Version", CF_CLIENT_VERSION) // validated server-side
                .header("Content-Type",      "application/json")
                .post(RequestBody.create(body.toString(), JSON_MEDIA_TYPE))
                .build();

        try (Response response = HTTP_CLIENT.newCall(request).execute()) {
            ResponseBody responseBody = response.body();
            String       rawResponse  = responseBody != null ? responseBody.string() : "";

            if (!response.isSuccessful()) {
                throw new IOException(
                        "WARP registration failed — HTTP " + response.code()
                                + ": " + rawResponse);
            }

            Log.d(TAG, "WARP registration response received ("
                    + rawResponse.length() + " bytes)");
            return rawResponse;
        }
    }

    /**
     * Parses the proxy registration JSON response into a {@link WarpConfig}.
     *
     * <p>Expected response shape (mirrors the real Cloudflare WARP API):
     * <pre>
     * {
     *   "config": {
     *     "client_id": "...",
     *     "peers": [{
     *       "public_key": "...",
     *       "endpoint": { "host": "host:port" }
     *     }],
     *     "interface": {
     *       "addresses": { "v4": "...", "v6": "..." }
     *     }
     *   },
     *   "session": {
     *     "expires_at": "...",
     *     "issued_at":  "...",
     *     "api_version": "..."
     *   }
     * }
     * </pre>
     *
     * @param rawJson The raw JSON string from the proxy.
     * @param privB64 The client's private key (base64).
     * @param pubB64  The client's public key (base64).
     * @return A fully populated {@link WarpConfig}.
     * @throws Exception on JSON parse errors or missing required fields.
     */
    private static WarpConfig parseRegistrationResponse(
            String rawJson,
            String privB64,
            String pubB64) throws Exception {

        JSONObject root   = new JSONObject(rawJson);
        JSONObject config = root.getJSONObject("config");

        // peers[0] → server public key + endpoint
        JSONArray  peers  = config.getJSONArray("peers");
        JSONObject peer0  = peers.getJSONObject(0);
        String     srvPub = peer0.getString("public_key");
        String     epHost = peer0.getJSONObject("endpoint").getString("host");

        // interface.addresses → v4 / v6
        JSONObject addresses = config.getJSONObject("interface").getJSONObject("addresses");
        String     v4        = addresses.getString("v4");
        String     v6        = addresses.getString("v6");

        String clientId = config.optString("client_id", "");

        // Log session metadata if present (informational only — not stored)
        if (root.has("session")) {
            JSONObject session = root.getJSONObject("session");
            Log.d(TAG, "Session issued_at="  + session.optString("issued_at")
                    + " expires_at=" + session.optString("expires_at")
                    + " api_version=" + session.optString("api_version"));
        }

        return new WarpConfig(privB64, pubB64, srvPub, epHost, v4, v6, clientId);
    }

    /** Persists all {@link WarpConfig} fields atomically to {@link SharedPreferences}. */
    private static void persistToCache(SharedPreferences prefs, WarpConfig config) {
        prefs.edit()
                .putString(K_PRIV,      config.privateKeyBase64)
                .putString(K_PUB,       config.publicKeyBase64)
                .putString(K_SRV_PUB,   config.serverPublicKey)
                .putString(K_ENDPOINT,  config.endpoint)
                .putString(K_V4,        config.v4Address)
                .putString(K_V6,        config.v6Address)
                .putString(K_CLIENT_ID, config.clientId)
                .apply();
    }

    /** Returns the current UTC time formatted as an ISO-8601 string. */
    private static String iso8601Now() {
        SimpleDateFormat df =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }
}